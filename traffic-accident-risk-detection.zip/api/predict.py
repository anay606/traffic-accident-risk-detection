import json
import joblib
import pandas as pd
from http.server import BaseHTTPRequestHandler
import sys
import os

# Load model once at module level
MODEL_PATH = os.path.join(os.path.dirname(__file__), '..', 'accident_model.pkl')
SCALER_PATH = os.path.join(os.path.dirname(__file__), '..', 'scaler.pkl')

model = joblib.load(MODEL_PATH)
scaler = joblib.load(SCALER_PATH)

def predict_risk(data):
    """Make prediction from input data."""
    hour = data.get('hour', 12)
    weather = data.get('weather', 'Clear')
    traffic_volume = data.get('traffic_volume', 2000)
    avg_speed = data.get('avg_speed', 45)
    speed_variance = data.get('speed_variance', 12)
    visibility = data.get('visibility', 8)

    features = pd.DataFrame({
        'hour': [hour],
        'is_rush_hour': [1 if hour in [7,8,9,17,18,19] else 0],
        'is_night': [1 if hour < 6 or hour > 20 else 0],
        'is_weekend': [0],
        'is_rain': [1 if weather == 'Rain' else 0],
        'is_fog': [1 if weather == 'Fog' else 0],
        'is_snow': [1 if weather == 'Snow' else 0],
        'traffic_volume': [traffic_volume],
        'avg_speed': [avg_speed],
        'speed_variance': [speed_variance],
        'visibility': [visibility]
    })

    X = scaler.transform(features)
    risk_prob = model.predict_proba(X)[0][1]

    if risk_prob < 0.15:
        level = "Low"
    elif risk_prob < 0.35:
        level = "Moderate"
    elif risk_prob < 0.6:
        level = "High"
    else:
        level = "Critical"

    return {
        "risk_probability": round(float(risk_prob), 3),
        "risk_level": level,
        "recommendation": "Deploy emergency response" if risk_prob > 0.5 else "Increase monitoring" if risk_prob > 0.25 else "Normal operations"
    }

class handler(BaseHTTPRequestHandler):
    def do_POST(self):
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length)
            data = json.loads(body.decode('utf-8'))
            result = predict_risk(data)

            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')
            self.send_header('Access-Control-Allow-Headers', 'Content-Type')
            self.end_headers()
            self.wfile.write(json.dumps(result).encode())
        except Exception as e:
            self.send_response(500)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"error": str(e)}).encode())

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps({
            "message": "Traffic Accident Risk API",
            "status": "active",
            "usage": "POST to this endpoint with JSON body containing: hour, weather, traffic_volume, avg_speed, speed_variance, visibility"
        }).encode())
