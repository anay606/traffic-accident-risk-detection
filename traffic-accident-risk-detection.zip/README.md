# 🚦 Traffic Accident Risk Detection

A machine learning project that predicts traffic accident risk based on real-world traffic and weather conditions. Built for resume/portfolio to demonstrate end-to-end ML pipeline skills.

## The Real Problem

Traffic accidents cause **1.3M+ deaths globally each year** (WHO). Emergency response is often delayed because accidents are reported manually via 911 calls, typically **5-15 minutes after occurrence**. This project builds a predictive model that identifies high-risk traffic conditions **before** accidents happen, enabling proactive emergency deployment.

## What This Project Does

- **Predicts accident probability** from traffic sensor data (volume, speed, variance) and weather conditions
- **Identifies risk factors** that contribute most to accidents (visibility, speed variance, weather)
- **Provides actionable recommendations** for traffic management centers

## Dataset

| Feature | Description | Source |
|---------|-------------|--------|
| `hour` | Time of day (0-23) | Traffic sensors |
| `is_rush_hour` | 7-9 AM or 5-7 PM | Derived |
| `is_night` | Before 6 AM or after 8 PM | Derived |
| `weather` | Clear/Rain/Fog/Snow | Weather API |
| `traffic_volume` | Vehicles per hour | Traffic sensors |
| `avg_speed` | Average speed (mph) | Traffic sensors |
| `speed_variance` | Speed deviation | Traffic sensors |
| `visibility` | Visibility in miles | Weather API |
| `accident` | Target: 1 if accident occurred | Historical records |

- **20,000 hourly records** spanning 2+ years
- **3.4% accident rate** (realistic class imbalance)
- **Synthetic but realistic** — based on US DOT accident patterns

## Model

**Algorithm:** Random Forest Classifier (150 trees, max depth 8)

**Why Random Forest?**
- Handles class imbalance well with `class_weight='balanced'`
- Built-in feature importance for interpretability
- No need for complex scaling/feature engineering
- Fast training and inference

**Performance:**
| Metric | Score |
|--------|-------|
| Test AUC-ROC | 0.628 |
| Test Accuracy | 83.9% |
| Accident Recall | 33% |

> Note: 33% recall means we catch 1 in 3 accidents before they happen — valuable for proactive deployment. The low precision (8%) is expected given the 3.4% base rate; in production, you'd tune the threshold based on cost of false alarms vs missed accidents.

## Key Insights

**Top Risk Factors (from feature importance):**
1. **Visibility** (25%) — Most important factor
2. **Speed Variance** (19%) — High variance = dangerous
3. **Average Speed** (15%) — Speed alone matters
4. **Traffic Volume** (14%) — More cars = more risk
5. **Hour of Day** (9%) — Time patterns matter

**Risk Scenarios:**
| Scenario | Risk | Action |
|----------|------|--------|
| Clear afternoon, normal traffic | 21% | Normal ops |
| Rainy rush hour, high volume | 63% | Deploy emergency |
| Foggy night, low visibility | 44% | Increase monitoring |
| Snowy morning, slow traffic | 48% | Increase monitoring |

## Project Structure

```
traffic-accident-risk-detection/
├── traffic_data.csv          # Dataset (20K records)
├── accident_model.pkl        # Trained Random Forest model
├── scaler.pkl                # Feature scaler
├── results.json              # Model performance metrics
├── feature_importance.png    # Feature importance chart
├── confusion_matrix.png      # Confusion matrix
├── train.py                  # Training script
├── predict.py                # Prediction script
└── README.md                 # This file
```

## Quick Start

### 1. Install dependencies
```bash
pip install pandas numpy scikit-learn joblib matplotlib seaborn
```

### 2. Train the model
```bash
python train.py
```

### 3. Make predictions
```python
from predict import predict_accident_risk

result = predict_accident_risk(
    hour=18,
    weather='Rain',
    traffic_volume=4500,
    avg_speed=30,
    speed_variance=22,
    visibility=3
)

print(result)
# {'risk_probability': 0.627, 'risk_level': 'Critical', 'recommendation': 'Deploy emergency response'}
```



## 🚀 Deployment Options

### Option 1: Streamlit Community Cloud (FREE - Easiest)

Best for: Interactive demos, portfolio showcases

1. Push this repo to GitHub
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Sign in with GitHub
4. Select your repo → Choose `streamlit_app.py` → Click Deploy
5. Your app goes live in ~2 minutes with a public URL

**Pros:** Completely free, auto-updates on git push, no server management citeweb_search:26#9

---

### Option 2: Render (FREE Tier)

Best for: REST API, production-like deployment

1. Push this repo to GitHub
2. Go to [render.com](https://render.com) → Sign up with GitHub
3. Click "New Web Service" → Connect your repo
4. Render auto-detects `render.yaml` and configures everything
5. Your API goes live with a public URL

**Test the API:**
```bash
curl -X POST https://your-app.onrender.com/predict \
  -H "Content-Type: application/json" \
  -d '{"hour": 18, "weather": "Rain", "traffic_volume": 4500, "avg_speed": 30, "speed_variance": 22, "visibility": 3}'
```

**Pros:** Free tier available, custom domains, auto-deploy from Git citeweb_search:26#0

---

### Option 3: Railway (Free Credits)

Best for: Fast iteration, developer-friendly

1. Push this repo to GitHub
2. Go to [railway.app](https://railway.app)
3. Click "New Project" → Deploy from GitHub repo
4. Railway auto-detects Python and deploys
5. Get $5 free credits to start citeweb_search:26#5

---

### Option 4: GitHub Only (No Deployment)

Just push the code to GitHub. This is perfectly fine for:
- Resume projects
- Code review in interviews
- Portfolio documentation

**What recruiters see:** Clean repo, good README, working code, clear results


## How to Improve This Project

**For your resume, mention these next steps:**

1. **Real Data Integration** — Connect to live traffic APIs (TomTom, HERE) and weather APIs (OpenWeatherMap)
2. **Deep Learning Upgrade** — Replace Random Forest with CNN+LSTM for temporal pattern capture
3. **Real-time Pipeline** — Build Kafka/Spark streaming pipeline for live predictions
4. **Geospatial Layer** — Add road segment risk mapping with Folium/Mapbox
5. **Threshold Tuning** — Optimize precision/recall tradeoff based on operational costs

## Resume Bullet Points

> **"Built a machine learning model to predict traffic accident risk from sensor and weather data, achieving 63% AUC-ROC and identifying visibility and speed variance as top risk factors."**

> **"Engineered an end-to-end ML pipeline: synthetic data generation → feature engineering → Random Forest training → model evaluation with confusion matrices and feature importance analysis."**

> **"Addressed 3.4% class imbalance using balanced class weights, achieving 33% recall for accident detection — enabling proactive emergency response deployment."**

## Tech Stack

- **Python** — Core language
- **pandas/numpy** — Data manipulation
- **scikit-learn** — Random Forest, metrics, preprocessing
- **matplotlib/seaborn** — Visualization
- **joblib** — Model serialization

## License

MIT License — Free to use for learning and portfolio projects.

---

**Built for:** ML/DS Resume & Portfolio  
**Time to build:** ~4-6 hours  
**Complexity:** Beginner-Intermediate
