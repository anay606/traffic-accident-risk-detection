# Traffic Accident Risk Detection - Demo

## 1. Load and Explore Data

```python
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('traffic_data.csv')
print(f"Dataset: {len(df)} records")
print(f"Accidents: {df['accident'].sum()} ({df['accident'].mean():.1%})")
print(df.head())
```

## 2. Make Predictions

```python
from predict import predict_accident_risk

# Clear afternoon
result = predict_accident_risk(
    hour=14, weather='Clear', traffic_volume=2000,
    avg_speed=55, speed_variance=8, visibility=9
)
print(result)

# Rainy rush hour
result = predict_accident_risk(
    hour=18, weather='Rain', traffic_volume=4500,
    avg_speed=30, speed_variance=22, visibility=3
)
print(result)
```

## 3. Retrain Model

```python
# Run: python train.py
# Or import and run:
# exec(open('train.py').read())
```
