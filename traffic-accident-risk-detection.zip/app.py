"""
app.py - FastAPI app for Render deployment
Deploy: Connect GitHub repo to Render, set build command and start command
"""
from fastapi import FastAPI
from pydantic import BaseModel
import numpy as np
import joblib
import pandas as pd

app = FastAPI(title="Traffic Accident Risk API")

# Load model
model = joblib.load("accident_model.pkl")
scaler = joblib.load("scaler.pkl")

class TrafficInput(BaseModel):
    hour: int
    weather: str  # Clear, Rain, Fog, Snow
    traffic_volume: int
    avg_speed: float
    speed_variance: float
    visibility: float

@app.get("/")
def home():
    return {"message": "Traffic Accident Risk API", "status": "active"}

@app.post("/predict")
def predict(data: TrafficInput):
    features = pd.DataFrame({
        'hour': [data.hour],
        'is_rush_hour': [1 if data.hour in [7,8,9,17,18,19] else 0],
        'is_night': [1 if data.hour < 6 or data.hour > 20 else 0],
        'is_weekend': [0],
        'is_rain': [1 if data.weather == 'Rain' else 0],
        'is_fog': [1 if data.weather == 'Fog' else 0],
        'is_snow': [1 if data.weather == 'Snow' else 0],
        'traffic_volume': [data.traffic_volume],
        'avg_speed': [data.avg_speed],
        'speed_variance': [data.speed_variance],
        'visibility': [data.visibility]
    })

    X = scaler.transform(features)
    risk = model.predict_proba(X)[0][1]

    level = "Low" if risk < 0.15 else "Moderate" if risk < 0.35 else "High" if risk < 0.6 else "Critical"

    return {
        "risk_probability": round(float(risk), 3),
        "risk_level": level,
        "recommendation": "Deploy emergency response" if risk > 0.5 else "Increase monitoring" if risk > 0.25 else "Normal operations"
    }
