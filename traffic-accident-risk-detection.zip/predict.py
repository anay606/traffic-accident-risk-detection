"""
predict.py
Make accident risk predictions using the trained model.
"""
import pandas as pd
import numpy as np
import joblib

def predict_accident_risk(hour, weather, traffic_volume, avg_speed, speed_variance, visibility):
    """
    Predict accident risk from traffic conditions.

    Args:
        hour: int (0-23)
        weather: str ('Clear', 'Rain', 'Fog', 'Snow')
        traffic_volume: int (vehicles/hour)
        avg_speed: float (mph)
        speed_variance: float
        visibility: float (miles, 0.1-10)

    Returns:
        dict with risk probability, level, and recommendation
    """
    model = joblib.load("accident_model.pkl")
    scaler = joblib.load("scaler.pkl")

    features = pd.DataFrame({
        'hour': [hour],
        'is_rush_hour': [1 if hour in [7,8,9,17,18,19] else 0],
        'is_night': [1 if hour < 6 or hour > 20 else 0],
        'is_weekend': [0],
        'is_rain': [1 if weather == 'Rain' else 0],
        'is_fog': [1 if weather == 'Fog' else 0],
        'is_snow': [1 if weather == 'Snow' else 0],
        'traffic_volume': [traffic_volume],
        'avg_speed': [avg_speed],
        'speed_variance': [speed_variance],
        'visibility': [visibility]
    })

    X = scaler.transform(features)
    risk_prob = model.predict_proba(X)[0][1]

    if risk_prob < 0.15: level = "Low"
    elif risk_prob < 0.35: level = "Moderate"
    elif risk_prob < 0.6: level = "High"
    else: level = "Critical"

    return {
        'risk_probability': round(risk_prob, 3),
        'risk_level': level,
        'recommendation': 'Deploy emergency response' if risk_prob > 0.5 else 
                         'Increase monitoring' if risk_prob > 0.25 else 'Normal operations'
    }

if __name__ == "__main__":
    # Example predictions
    scenarios = [
        (14, 'Clear', 2000, 55, 8, 9, "Clear Afternoon"),
        (18, 'Rain', 4500, 30, 22, 3, "Rainy Rush Hour"),
        (23, 'Fog', 1200, 40, 18, 0.5, "Foggy Night"),
        (8, 'Snow', 3500, 25, 15, 2, "Snowy Morning"),
    ]

    print("Traffic Accident Risk Predictions")
    print("=" * 50)

    for hour, weather, vol, speed, var, vis, desc in scenarios:
        result = predict_accident_risk(hour, weather, vol, speed, var, vis)
        print(f"\n{desc}:")
        print(f"  Risk: {result['risk_probability']:.1%} ({result['risk_level']})")
        print(f"  Action: {result['recommendation']}")
