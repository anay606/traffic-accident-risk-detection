import streamlit as st
import pandas as pd
import numpy as np
import joblib

st.set_page_config(page_title="TrafficGuard AI", page_icon="🚦")

st.markdown("<h1 style='text-align: center;'>🚦 TrafficGuard AI</h1>", unsafe_allow_html=True)
st.markdown("<p style='text-align: center;'>Predict accident risk from traffic conditions</p>", unsafe_allow_html=True)

# Load model
@st.cache_resource
def load_model():
    return joblib.load("accident_model.pkl"), joblib.load("scaler.pkl")

model, scaler = load_model()

st.sidebar.header("Traffic Conditions")

hour = st.sidebar.slider("Hour", 0, 23, 14)
weather = st.sidebar.selectbox("Weather", ["Clear", "Rain", "Fog", "Snow"])
traffic_volume = st.sidebar.slider("Traffic Volume", 100, 6000, 2500)
avg_speed = st.sidebar.slider("Avg Speed (mph)", 5, 75, 45)
speed_variance = st.sidebar.slider("Speed Variance", 0, 50, 12)
visibility = st.sidebar.slider("Visibility (miles)", 0.1, 10.0, 8.0)

if st.sidebar.button("🚀 Predict Risk", type="primary"):
    features = pd.DataFrame({
        'hour': [hour],
        'is_rush_hour': [1 if hour in [7,8,9,17,18,19] else 0],
        'is_night': [1 if hour < 6 or hour > 20 else 0],
        'is_weekend': [0],
        'is_rain': [1 if weather == 'Rain' else 0],
        'is_fog': [1 if weather == 'Fog' else 0],
        'is_snow': [1 if weather == 'Snow' else 0],
        'traffic_volume': [traffic_volume],
        'avg_speed': [avg_speed],
        'speed_variance': [speed_variance],
        'visibility': [visibility]
    })

    X = scaler.transform(features)
    risk = model.predict_proba(X)[0][1]

    col1, col2, col3 = st.columns(3)

    if risk < 0.15:
        color, level, emoji = "#2ecc71", "Low", "🟢"
    elif risk < 0.35:
        color, level, emoji = "#f39c12", "Moderate", "🟡"
    elif risk < 0.6:
        color, level, emoji = "#e74c3c", "High", "🔴"
    else:
        color, level, emoji = "#8e44ad", "Critical", "🟣"

    with col1:
        st.markdown(f"<div style='background:{color}20; padding:20px; border-radius:10px; text-align:center; border:3px solid {color}'>"
                   f"<div style='font-size:3rem'>{emoji}</div>"
                   f"<div style='font-size:2.5rem; font-weight:bold; color:{color}'>{risk:.1%}</div>"
                   f"<div style='color:{color}'>{level} Risk</div></div>", unsafe_allow_html=True)

    with col2:
        st.metric("Traffic Volume", f"{traffic_volume:,}")
        st.metric("Avg Speed", f"{avg_speed} mph")

    with col3:
        st.metric("Visibility", f"{visibility} mi")
        st.metric("Weather", weather)

    st.info(f"**Recommendation:** {'Deploy emergency response teams' if risk > 0.5 else 'Increase monitoring' if risk > 0.25 else 'Normal operations - no action needed'}")

    # Risk breakdown
    st.subheader("Risk Factor Breakdown")
    factors = {
        "Visibility": (10 - visibility) / 10,
        "Speed Variance": speed_variance / 50,
        "Traffic Volume": traffic_volume / 6000,
        "Weather Risk": 1 if weather != "Clear" else 0,
        "Time Risk": 0.8 if hour in [7,8,9,17,18,19] else (0.6 if hour < 6 or hour > 20 else 0.2)
    }

    chart_data = pd.DataFrame({"Factor": list(factors.keys()), "Score": list(factors.values())})
    chart_data = chart_data.sort_values("Score", ascending=True)
    st.bar_chart(chart_data.set_index("Factor"))

st.markdown("---")
st.markdown("<p style='text-align:center; color:#888'>Built with ❤️ for ML Portfolio</p>", unsafe_allow_html=True)
