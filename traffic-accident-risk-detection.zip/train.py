"""
train.py
Complete training pipeline for traffic accident risk prediction.
Run: python train.py
"""
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, roc_auc_score, confusion_matrix
import joblib
import json
import matplotlib.pyplot as plt
import seaborn as sns

# Load data
print("Loading data...")
df = pd.read_csv("traffic_data.csv")

# Features and target
feature_cols = [
    'hour', 'is_rush_hour', 'is_night', 'is_weekend',
    'is_rain', 'is_fog', 'is_snow',
    'traffic_volume', 'avg_speed', 'speed_variance', 'visibility'
]
X = df[feature_cols]
y = df['accident']

# Time-based split
n = len(df)
X_train, y_train = X.iloc[:int(n*0.7)], y.iloc[:int(n*0.7)]
X_val, y_val = X.iloc[int(n*0.7):int(n*0.85)], y.iloc[int(n*0.7):int(n*0.85)]
X_test, y_test = X.iloc[int(n*0.85):], y.iloc[int(n*0.85):]

print(f"Train: {len(X_train)}, Val: {len(X_val)}, Test: {len(X_test)}")

# Scale
scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_val_s = scaler.transform(X_val)
X_test_s = scaler.transform(X_test)

# Train
print("Training Random Forest...")
rf = RandomForestClassifier(
    n_estimators=150, max_depth=8, min_samples_split=10,
    min_samples_leaf=5, class_weight='balanced', random_state=42, n_jobs=-1
)
rf.fit(X_train_s, y_train)

# Evaluate
val_pred = rf.predict_proba(X_val_s)[:, 1]
print(f"Val AUC: {roc_auc_score(y_val, val_pred):.3f}")

test_pred = rf.predict_proba(X_test_s)[:, 1]
test_auc = roc_auc_score(y_test, test_pred)
test_acc = (rf.predict(X_test_s) == y_test).mean()

print(f"\nTest AUC: {test_auc:.3f} | Accuracy: {test_acc:.3f}")
print("\nClassification Report:")
print(classification_report(y_test, rf.predict(X_test_s), target_names=['No Accident', 'Accident']))

# Feature importance
importance = pd.DataFrame({
    'feature': feature_cols, 'importance': rf.feature_importances_
}).sort_values('importance', ascending=True)

plt.figure(figsize=(10, 6))
plt.barh(importance['feature'], importance['importance'], color='steelblue')
plt.xlabel('Importance')
plt.title('Feature Importance')
plt.tight_layout()
plt.savefig("feature_importance.png", dpi=150)
plt.show()

# Confusion matrix
cm = confusion_matrix(y_test, rf.predict(X_test_s))
plt.figure(figsize=(7, 5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
           xticklabels=['No Accident', 'Accident'],
           yticklabels=['No Accident', 'Accident'])
plt.title('Confusion Matrix')
plt.ylabel('Actual')
plt.xlabel('Predicted')
plt.tight_layout()
plt.savefig("confusion_matrix.png", dpi=150)
plt.show()

# Save
joblib.dump(rf, "accident_model.pkl")
joblib.dump(scaler, "scaler.pkl")

results = {
    'test_auc': round(test_auc, 3),
    'test_accuracy': round(test_acc, 3),
    'features': feature_cols
}
with open("results.json", "w") as f:
    json.dump(results, f, indent=2)

print("\n✅ Model saved: accident_model.pkl")
